tellraw @a {"text":"[repro] Reloading NOW. When this finishes, take the sticks.","color":"yellow"}
reload
